원장을 위한 AI 실전 교육 — 스타터 키트

이 키트를 설치하면, 만들고 싶은 프로그램을 Claude에게 말로 주문했을 때
  GitHub(설계도 보관) → Vercel(주소·서버) → Supabase(데이터 보관)
까지 자동으로 이어져 휴대폰에서 바로 쓰는 앱이 됩니다.

들어 있는 것
  claude-md-block.md   규칙집 — Claude가 대화를 시작할 때마다 읽는 우리 병원 원칙
  skills/vet-app/      조립법 — 앱 만드는 순서, 배포 도구(vetapp), 빈 앱 틀
  INSTALL.md           Claude가 읽고 설치하는 순서

설치: Claude 앱에서 "이 폴더의 INSTALL.md대로 설치해 줘"라고 말씀하시면 됩니다.
