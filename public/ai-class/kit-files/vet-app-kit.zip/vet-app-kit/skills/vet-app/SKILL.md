---
name: vet-app
description: 원장님이 "앱 만들어줘", "프로그램 만들어줘", "이런 거 있었으면 좋겠어", "○○ 기록하는 화면", "고쳐줘", "배포해줘", "주소 알려줘", "비밀번호 잊었어"라고 하면 반드시 이 스킬을 쓴다. 말로 주문한 웹앱(PWA)을 만들고 GitHub(비공개 저장소)·Vercel(주소·서버)·Supabase(저장소)까지 자동으로 이어 배포한다. 처음 쓰는 컴퓨터면 준비(도구 설치·로그인·열쇠)부터 한다.
---

# 말로 주문한 앱을 만들고 배포하기

원장님은 코딩을 모른다. 원장님이 하실 일은 **무엇이 필요한지 말하기**, **로그인 승인**, **열쇠 붙여 넣기**, **휴대폰에서 써 보기** 네 가지뿐이다. 나머지는 전부 내가 한다.

도구: 이 스킬 폴더의 `bin/vetapp` (bash). 맥은 터미널, 윈도우는 Git Bash에서 돈다.
아래에서 `vetapp`은 `"<이 스킬 폴더>/bin/vetapp"`을 뜻한다(`~/.claude/skills/vet-app/bin/vetapp`).

## 0. 처음 한 번 — 준비

`vetapp doctor`를 먼저 돌려서 빠진 것만 채운다. 순서:

1. `vetapp setup` — Node·GitHub CLI·Vercel CLI를 `~/.vetapp/tools`에 설치(관리자 비밀번호 필요 없음).
2. `vetapp login-github` — **백그라운드로** 실행하고 출력에서 `XXXX-XXXX` 코드를 찾아 원장님께 보여 드린다:
   "https://github.com/login/device 를 열고, 'Signed in as (내 아이디)' 옆 **Continue** → 코드 `XXXX-XXXX` 넣기 → **Continue** → **Authorize github**를 눌러 주십시오."
   끝나면 출력에 `[됨] GitHub 로그인`이 나온다.
3. `vetapp login-vercel` — 역시 백그라운드로 실행하고, 출력에 나온 `https://vercel.com/...` 주소(코드가 있으면 코드도)를
   그대로 원장님께 드린다: "이 주소를 열고 코드가 같은지 본 뒤 **Allow Access**를 눌러 주십시오(**Continue**가 먼저 보이면 Continue → Allow Access)." 끝나면 `[됨] Vercel 로그인`.
4. Supabase 프로젝트가 없으면 원장님께 단계별로 안내한다(원장님이 직접):
   1) 처음 가입: https://supabase.com/dashboard/new 열기 → **Create a new organization** 화면에서 Name(병원 이름), Type(Company), Plan(Free 그대로) → **Create organization**
      이미 계정이 있음: https://supabase.com/dashboard/organizations → 조직 열기 → **New project**
   2) **Project name**: 미리 적힌 글자를 지우고 `clinic-apps` / **Database password**: **Generate a password** → 따로 적어 두기
   3) **Region** 칸 아래 **Need a specific region?** → `Northeast Asia (Seoul)` — 나중에 못 바꾼다. 링크나 서울이 안 보이면 `Asia-Pacific`
   4) **Create new project** → 1~2분 기다리기
5. `vetapp keys` — 열쇠 파일이 메모장(맥은 텍스트 편집기)으로 열린다. 원장님께:
   1) 방금 만든 프로젝트 화면 주소창의 `https://supabase.com/dashboard/project/` 뒤 영문 글자를 복사해 `SUPABASE_URL=` 뒤에 붙여 넣기
   2) https://supabase.com/dashboard/project/_/settings/api-keys 열기 → 프로젝트 고르기 → **Secret keys** 칸의 키 오른쪽 복사 버튼 → `SUPABASE_SECRET_KEY=` 뒤에 붙여 넣기
      (Secret key가 없으면 **+ New secret key** → 이름 `apps` → **Create API key**)
   3) 저장하고 닫기 → "저장했습니다"라고 말씀하시면 `vetapp doctor`로 확인
6. `vetapp doctor`가 "모두 준비됐습니다"를 내면 끝.

**절대 규칙: 비밀 키(sb_secret_…, 비밀번호)를 채팅에 붙여 넣게 하지 않는다. 원장님이 붙여 넣으면 즉시
"그 키는 노출됐으니 Supabase API Keys 화면에서 지우고 새로 만들어 열쇠 파일에 다시 넣어 주십시오"라고 안내한다.
열쇠 파일 내용을 cat 등으로 화면에 출력하지 않는다.**

## 1. 주문 받기 — 만들기 전에 짧게 확인

원장님 말이 막연하면 **한 번에 최대 3개**만 묻는다. 꼭 알아야 할 것:
- 누가 쓰나(원장님 혼자 / 직원 여럿 / 보호자) · 어떤 기기(휴대폰 / 진료실 PC)
- 무엇을 적고 무엇을 보나(입력 칸, 목록·검색·합계)
- 여러 사람이 같은 데이터를 보나(보통 그렇다 → 동기화 기본 포함)
나머지는 상식적인 기본값으로 정하고 "이렇게 만들겠습니다"라고 한 줄로 알린 뒤 바로 만든다.

## 2. 만들기

1. `vetapp new <영문-이름> "<앱 제목>"` — `~/vet-apps/<영문-이름>`에 틀이 생긴다(로그인·동기화·뒤로가기·PWA 완비).
   이름은 영문 소문자·숫자·하이픈(예: `stock-check`, `surgery-log`). 이 이름이 주소(`<이름>.vercel.app`)가 된다.
2. `public/index.html`을 주문대로 고친다. 지킬 것:
   - **상태는 `state` 한 벌**에 담고, 바뀌면 `changed()`를 부른다(저장·동기화가 따라온다).
   - 지우기는 `deleted:true` 묘비로. 항목마다 `id`, `at`(고친 시각)을 둔다. 구조가 다르면 `merge()`도 맞게 고친다.
   - 화면을 옮길 때는 `go(화면, id)`만 쓰고, 화면 안 "← 뒤로" 버튼은 `history.back()`. **뒤로가기로 앱이 꺼지면 안 된다.**
   - 로그인·`createSync`·서비스 워커 등록 부분은 지우지 않는다.
   - 사진·PDF가 필요하면 `api/files.js`를 쓴다: 올리기 전에 긴 변 1600px·JPEG 0.8로 줄이고, `POST /api/files`(헤더 `x-app-key`) → 받은 `id`만 state에 적는다. 보여 줄 때 `/api/files?id=<id>&key=<비밀번호>`.
   - 휴대폰 먼저: 글자 16px 이상, 누르는 곳 44px 이상, 가로 스크롤 없음.
   - 디자인은 차분하게: 색은 한두 가지, 이모지 아이콘·보라 그라디언트·카드 속 카드 금지. 위계·여백으로 정리.
3. **시험은 가짜 데이터로.** 실제 환자·보호자 이름, 전화번호를 넣어 시험하지 않는다.
4. `api/` 서버 코드를 고쳤으면 `node --check api/파일.js`.

## 3. 배포 — 항상 이 한 줄

```bash
vetapp ship ~/vet-apps/<영문-이름> "무엇을 바꿨는지 한 줄"
```

하는 일: 문법 점검 → 서비스 워커 버전 올림(휴대폰이 새 화면을 받게) → GitHub 비공개 저장소에 올림(처음이면 만듦)
→ Vercel 프로젝트(처음이면 만들고 Supabase 열쇠·앱 비밀번호를 환경변수로 넣음) → 운영 배포 → 저장소 쓰기·읽기 점검.
끝에 **주소와 비밀번호**가 나온다. 원장님께 이렇게 알린다:

> 주소: https://…vercel.app · 비밀번호: xxxx-xxxx
> 휴대폰에서 주소를 열고 비밀번호를 넣은 뒤 홈 화면에 올리시면 앱처럼 쓰실 수 있습니다.
> 아이폰: Safari 주소창 옆 '…'(또는 공유 버튼) → 공유 → **홈 화면에 추가** → '웹 앱으로 열기' 켜고 추가
> 안드로이드: Chrome 오른쪽 위 점 세 개 → **설치 및 바로가기 만들기**(또는 '홈 화면에 추가') → 설치

배포 후 가능하면 브라우저로 주소를 열어 첫 화면이 뜨는지, 화면 이동 → 뒤로가기 여러 번에 앱 밖으로 안 나가는지 확인한다.

## 4. 고치기

"○○ 고쳐줘" → `~/vet-apps/<이름>`에서 고치고 → 같은 `vetapp ship` 한 줄. 주소·비밀번호·데이터는 그대로다.
원장님 설명이 모호하면 "무엇을 눌렀고 / 무엇이 보였고 / 무엇을 기대하셨는지" 또는 화면 캡처를 부탁한다.
휴대폰에 옛 화면이 보이면: 앱을 완전히 닫았다가 다시 열면 된다.

## 5. 그 밖의 명령

- `vetapp list` — 내 앱 이름·주소·비밀번호
- `vetapp password <이름>` — 비밀번호 새로 만들기(직원이 그만뒀을 때 등). 쓰던 기기는 새 비밀번호를 한 번 넣어야 한다.
- `vetapp doctor` — 무엇이 안 되는지 모를 때 먼저

## 막힐 때

| 증상 | 원인·조치 |
|---|---|
| ship이 "Supabase 열쇠가 준비되지 않았습니다" | `vetapp doctor` → 표시대로. Publishable 키를 넣은 경우가 많다 |
| 앱 상단에 "서버 설정 필요" | Vercel 환경변수가 빠짐. 앱 폴더의 `.vercel`을 지우고 다시 `vetapp ship`(같은 이름이면 같은 프로젝트에 다시 연결된다) |
| 저장소 점검 실패 + 5xx | Supabase 무료 프로젝트가 오래 안 써서 멈춘 경우. https://supabase.com/dashboard/organizations 에서 조직·프로젝트를 열고 **Resume project** |
| GitHub 저장소 이름이 이미 있음 | ship이 `<이름>-app`으로 다시 시도한다 |
| Vercel 주소가 `<이름>-<팀이름>.vercel.app` | 같은 이름을 남이 이미 써서다. 그대로 써도 된다 |
| "명령을 찾을 수 없음" (윈도우) | Git Bash에서 돌고 있는지 확인. Claude 설정의 셸이 Git Bash여야 한다 |

## 원칙

- 모든 앱은 Supabase 프로젝트 **하나**를 같이 쓴다(앱마다 저장 경로가 달라 섞이지 않는다). 앱마다 프로젝트를 새로 만들지 않는다.
- Vercel 무료(Hobby) 요금제는 약관상 비상업적 개인 용도만 된다. 병원 업무용 앱은 Pro가 필요하다 — 원장님이 결제하시도록 안내만 하고, 결제는 대신 하지 않는다.
- 저장소(GitHub)는 항상 **비공개**. 진료 데이터는 GitHub가 아니라 Supabase에만 있다.
- 앱 비밀번호는 코드에 적지 않는다(Vercel 환경변수에만).
- 원장님이 직접 하셔야 하는 일은 **바로 열 수 있는 전체 주소 + 누를 버튼 이름 + 끝났는지 확인하는 법**을 번호 순서로 안내한다.
