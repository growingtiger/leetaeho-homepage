/* 사진·PDF 보관 (Vercel 서버리스 + Supabase Storage)
 *
 * 사진을 앱 데이터(JSON)에 넣으면 모든 기기가 느려진다. 파일은 따로 올리고 데이터에는 번호(id)만 적는다.
 *   POST /api/files { kind:"jpg"|"png"|"pdf", data:<base64> } (헤더 x-app-key) → { ok, id }
 *   GET  /api/files?id=…&key=<비밀번호>  → 파일 그대로 (<img src>에 바로 쓰려고 key를 주소로 받는다)
 *
 * 상한 4MB(Vercel 요청 한도 4.5MB). 사진은 앱에서 먼저 줄여서(긴 변 1600px, JPEG 0.8) 보낸다.
 */
const crypto = require("crypto");
const store = require("./_store.js");

const DIR = "__NS__/files/";
const MAX_BYTES = 4 * 1024 * 1024;
const KINDS = { jpg: "image/jpeg", png: "image/png", pdf: "application/pdf" };

function passOk(got) {
  const want = store.clean(process.env.APP_PASSWORD);
  if (!want || !got) return false;
  const h = (v) => crypto.createHash("sha256").update(String(v)).digest();
  return crypto.timingSafeEqual(h(want), h(got));
}

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  try {
    if (!store.enabled()) return res.status(200).json({ ok: false, error: "setup" });
    if (req.method === "GET") {
      const q = req.query || {};
      if (!passOk(q.key || req.headers["x-app-key"])) return res.status(401).json({ ok: false, error: "password" });
      const id = String(q.id || "");
      const m = id.match(/^([a-f0-9]{24})\.(jpg|png|pdf)$/);
      if (!m) return res.status(400).json({ ok: false, error: "id" });
      const bytes = await store.readBytes(DIR + id);
      if (!bytes) return res.status(404).json({ ok: false, error: "missing" });
      res.setHeader("Content-Type", KINDS[m[2]]);
      res.setHeader("Cache-Control", "private, max-age=86400");
      return res.status(200).send(bytes);
    }
    if (req.method === "POST") {
      if (!passOk(req.headers["x-app-key"])) return res.status(401).json({ ok: false, error: "password" });
      let body = req.body;
      if (typeof body === "string") { try { body = JSON.parse(body); } catch (e) { body = null; } }
      if (!body || !KINDS[body.kind]) return res.status(400).json({ ok: false, error: "kind" });
      const buf = Buffer.from(String(body.data || ""), "base64");
      if (!buf.length || buf.length > MAX_BYTES) return res.status(413).json({ ok: false, error: "size" });
      const id = crypto.randomBytes(12).toString("hex") + "." + body.kind;
      await store.writeBytes(DIR + id, buf, KINDS[body.kind]);
      return res.status(200).json({ ok: true, id });
    }
    return res.status(405).json({ ok: false, error: "method" });
  } catch (e) {
    return res.status(500).json({ ok: false, error: "server", detail: String((e && e.message) || e) });
  }
};
