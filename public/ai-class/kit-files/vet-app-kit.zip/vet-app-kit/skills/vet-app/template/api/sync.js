/* 앱 데이터 동기화 서버 (Vercel 서버리스 + Supabase Storage)
 *
 * 앱 데이터 전체를 JSON 한 벌로 보관한다. 여러 기기가 같은 데이터를 본다.
 *   GET  /api/sync?action=get&haveRev=N   (헤더 x-app-key) → { ok, rev, updatedAt, data? }
 *   GET  /api/sync?action=ping            (헤더 x-app-key) → 저장소 쓰기·읽기 점검
 *   POST /api/sync { action:"put", baseRev, data } (헤더 x-app-key) → { ok, rev } | { ok:false, conflict:true, rev, data }
 *
 * 비밀번호(APP_PASSWORD)는 Vercel 환경변수에만 있다. 코드에 적지 않는다.
 * 다른 기기가 먼저 저장했으면(baseRev가 다르면) 저장하지 않고 최신본을 돌려준다. 앱이 합쳐서 다시 보낸다.
 * NS는 배포 뒤에 바꾸지 않는다. 바꾸면 기존 데이터를 못 찾는다.
 */
const crypto = require("crypto");
const store = require("./_store.js");

const NS = "__NS__";
const DATA_PATH = NS + "/data.json";
const META_PATH = NS + "/meta.json";
const PING_PATH = NS + "/ping.json";

function passOk(req) {
  const want = store.clean(process.env.APP_PASSWORD);
  const got = String(req.headers["x-app-key"] || "");
  if (!want || !got) return false;
  const a = crypto.createHash("sha256").update(want).digest();
  const b = crypto.createHash("sha256").update(got).digest();
  return crypto.timingSafeEqual(a, b);
}

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  try {
    if (!store.enabled() || !store.clean(process.env.APP_PASSWORD)) {
      return res.status(200).json({ ok: false, error: "setup", diag: store.diagnostics() });
    }
    if (!passOk(req)) return res.status(401).json({ ok: false, error: "password" });

    if (req.method === "GET") {
      const q = req.query || {};
      if (q.action === "ping") {
        const out = await store.ping(PING_PATH);
        return res.status(200).json(Object.assign({ ok: out.writeOk && out.readOk }, out));
      }
      const meta = (await store.readJson(META_PATH)) || { rev: 0, updatedAt: "" };
      if (meta.rev > 0 && Number(q.haveRev) === meta.rev) {
        return res.status(200).json({ ok: true, rev: meta.rev, updatedAt: meta.updatedAt });
      }
      const data = meta.rev > 0 ? await store.readJson(DATA_PATH) : null;
      return res.status(200).json({ ok: true, rev: meta.rev, updatedAt: meta.updatedAt, data });
    }

    if (req.method === "POST") {
      let body = req.body;
      if (typeof body === "string") {
        try { body = JSON.parse(body); } catch (e) { return res.status(400).json({ ok: false, error: "parse" }); }
      }
      if (!body || body.action !== "put") return res.status(400).json({ ok: false, error: "action" });
      const meta = (await store.readJson(META_PATH)) || { rev: 0, updatedAt: "" };
      if (meta.rev > 0 && body.baseRev !== meta.rev) {
        const data = await store.readJson(DATA_PATH);
        return res.status(200).json({ ok: false, conflict: true, rev: meta.rev, updatedAt: meta.updatedAt, data });
      }
      const rev = meta.rev + 1;
      await store.writeJson(DATA_PATH, body.data);
      await store.writeJson(META_PATH, { rev, updatedAt: new Date().toISOString() });
      return res.status(200).json({ ok: true, rev });
    }
    return res.status(405).json({ ok: false, error: "method" });
  } catch (e) {
    return res.status(500).json({ ok: false, error: "server", detail: String((e && e.message) || e) });
  }
};
