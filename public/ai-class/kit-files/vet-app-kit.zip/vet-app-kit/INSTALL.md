# 설치 안내 (Claude가 읽고 실행하는 문서)

원장님이 "이 키트를 설치해 줘"라고 하셨다면 아래를 순서대로 한다. 원장님께는 진행 상황을 짧게 존댓말로 알린다.

1. 이 폴더(INSTALL.md가 있는 곳)를 `KIT`라고 하자.
2. 스킬 설치: `KIT/skills/vet-app` 폴더를 `~/.claude/skills/vet-app`으로 복사한다(이미 있으면 덮어쓴다).
   `chmod +x ~/.claude/skills/vet-app/bin/vetapp`
3. 규칙집 설치: `~/.claude/CLAUDE.md`(없으면 만든다)에 `KIT/claude-md-block.md` 내용을 넣는다.
   이미 `<!-- vet-app-kit:start` ~ `<!-- vet-app-kit:end -->` 블록이 있으면 그 블록만 새것으로 바꾸고,
   원장님이 따로 적어 둔 다른 내용은 건드리지 않는다.
4. 앱 폴더: `~/vet-apps` 를 만든다.
5. 준비: `~/.claude/skills/vet-app/SKILL.md`를 읽고 "0. 처음 한 번 — 준비"를 진행한다
   (`vetapp doctor` → `vetapp setup` → GitHub 로그인 → Vercel 로그인 → Supabase 프로젝트·열쇠).
6. `vetapp doctor`가 "모두 준비됐습니다"를 내면 원장님께 알린다:
   "준비가 끝났습니다. 이제 만들고 싶은 프로그램을 말씀해 주십시오. 다음 대화부터는 새 규칙이 적용됩니다."
   (규칙집은 새 대화를 시작할 때 읽힌다. 이 대화에서 바로 앱을 만들 때는 SKILL.md를 따르면 된다.)
